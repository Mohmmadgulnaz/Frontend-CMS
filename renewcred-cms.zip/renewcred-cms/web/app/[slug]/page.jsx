import { notFound } from 'next/navigation';
import SiteHeader from '../../components/SiteHeader';
import SiteFooter from '../../components/SiteFooter';
import BlockRenderer from '../../components/BlockRenderer';
import { getPublicPage } from '../../lib/content';

export const dynamic = 'force-dynamic';

export default async function ArticlePage({ params }) {
  const page = await getPublicPage(params.slug);
  if (!page) notFound();

  const toc = page.blocks
    .filter((b) => b.type === 'header')
    .map((b) => ({ id: b.id, text: b.data.text, anchor: b.data.anchor }));

  return (
    <>
      <SiteHeader />
      <main className="mx-auto grid max-w-5xl grid-cols-1 gap-10 px-6 py-10 md:grid-cols-[220px_1fr]">
        <aside className="hidden md:block">
          <div className="sticky top-8">
            <input
              placeholder="Search"
              className="mb-4 w-full rounded-md border border-neutral-200 px-3 py-1.5 text-sm text-neutral-500"
              readOnly
            />
            <nav className="space-y-1 text-sm">
              {toc.map((item) => (
                <a
                  key={item.id}
                  href={`#${item.anchor}`}
                  className="block rounded px-2 py-1 text-neutral-500 hover:bg-neutral-100 hover:text-ink"
                >
                  {item.text}
                </a>
              ))}
            </nav>
          </div>
        </aside>

        <article>
          <p className="mb-1 text-xs font-medium uppercase tracking-wide text-accent">Standards</p>
          <h1 className="mb-2 text-3xl font-bold tracking-tight text-ink">{page.title}</h1>
          {page.description && <p className="mb-8 max-w-xl text-neutral-500">{page.description}</p>}
          <BlockRenderer blocks={page.blocks} />
        </article>
      </main>
      <SiteFooter />
    </>
  );
}
