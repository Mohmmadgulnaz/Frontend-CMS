'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchAdminPage,
  updatePageMeta,
  saveBlocks,
  clearCurrentPage
} from '../../../../../../store/slices/contentSlice';
import BlockEditor from '../../../../../../components/BlockEditor';

export default function EditPagePage() {
  const { slug } = useParams();
  const dispatch = useDispatch();
  const router = useRouter();
  const { currentPage, editorStatus, saveStatus } = useSelector((state) => state.content);

  const [meta, setMeta] = useState({ title: '', description: '', status: 'draft' });
  const [blocks, setBlocks] = useState([]);

  useEffect(() => {
    dispatch(fetchAdminPage(slug));
    return () => dispatch(clearCurrentPage());
  }, [dispatch, slug]);

  useEffect(() => {
    if (currentPage) {
      setMeta({ title: currentPage.title, description: currentPage.description || '', status: currentPage.status });
      setBlocks(currentPage.blocks);
    }
  }, [currentPage]);

  async function handleSaveMeta() {
    await dispatch(updatePageMeta({ slug, meta }));
  }

  async function handleSaveBlocks() {
    // Strip client-only temp ids before sending; the backend regenerates
    // real ids and re-derives `order` from array position.
    const payload = blocks.map(({ type, data }) => ({ type, data }));
    await dispatch(saveBlocks({ slug, blocks: payload }));
  }

  if (editorStatus === 'loading' || !currentPage) {
    return <p className="text-sm text-neutral-400">Loading…</p>;
  }

  return (
    <div className="mx-auto max-w-3xl">
      <button onClick={() => router.push('/admin/dashboard')} className="mb-4 text-xs text-neutral-400 underline">
        ← Back to pages
      </button>

      <div className="mb-6 rounded-lg border border-neutral-200 bg-white p-5">
        <h2 className="mb-4 text-sm font-semibold text-ink">Page settings</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="mb-1 block text-xs font-medium text-neutral-600">Title</label>
            <input
              value={meta.title}
              onChange={(e) => setMeta((m) => ({ ...m, title: e.target.value }))}
              className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1 block text-xs font-medium text-neutral-600">Description</label>
            <textarea
              value={meta.description}
              onChange={(e) => setMeta((m) => ({ ...m, description: e.target.value }))}
              rows={2}
              className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-neutral-600">Status</label>
            <select
              value={meta.status}
              onChange={(e) => setMeta((m) => ({ ...m, status: e.target.value }))}
              className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
            >
              <option value="draft">Draft</option>
              <option value="published">Published</option>
            </select>
          </div>
        </div>
        <button onClick={handleSaveMeta} className="mt-4 rounded-md bg-ink px-3 py-1.5 text-xs font-medium text-white">
          Save settings
        </button>
      </div>

      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-sm font-semibold text-ink">Content blocks</h2>
        <button
          onClick={handleSaveBlocks}
          disabled={saveStatus === 'saving'}
          className="rounded-md bg-accent px-3 py-1.5 text-xs font-medium text-white disabled:opacity-60"
        >
          {saveStatus === 'saving' ? 'Saving…' : 'Save content'}
        </button>
      </div>

      <BlockEditor blocks={blocks} onChange={setBlocks} />
    </div>
  );
}
