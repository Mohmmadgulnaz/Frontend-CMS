'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useDispatch } from 'react-redux';
import { createPage } from '../../../../../store/slices/contentSlice';

export default function NewPagePage() {
  const [form, setForm] = useState({ title: '', slug: '', description: '', status: 'draft' });
  const [error, setError] = useState(null);
  const dispatch = useDispatch();
  const router = useRouter();

  function updateField(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    const result = await dispatch(createPage(form));
    if (createPage.fulfilled.match(result)) {
      router.push(`/admin/pages/${result.payload.slug}/edit`);
    } else {
      setError(result.payload || 'Failed to create page.');
    }
  }

  return (
    <div className="mx-auto max-w-lg">
      <h1 className="mb-6 text-xl font-semibold text-ink">New page</h1>
      <form onSubmit={handleSubmit} className="space-y-4 rounded-lg border border-neutral-200 bg-white p-6">
        <div>
          <label className="mb-1 block text-xs font-medium text-neutral-600">Title</label>
          <input
            value={form.title}
            onChange={(e) => updateField('title', e.target.value)}
            className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
            required
          />
        </div>
        <div>
          <label className="mb-1 block text-xs font-medium text-neutral-600">Slug</label>
          <input
            value={form.slug}
            onChange={(e) => updateField('slug', e.target.value.toLowerCase())}
            placeholder="e.g. methane"
            className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
            pattern="[a-z0-9-]+"
            required
          />
        </div>
        <div>
          <label className="mb-1 block text-xs font-medium text-neutral-600">Description</label>
          <textarea
            value={form.description}
            onChange={(e) => updateField('description', e.target.value)}
            rows={3}
            className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="mb-1 block text-xs font-medium text-neutral-600">Status</label>
          <select
            value={form.status}
            onChange={(e) => updateField('status', e.target.value)}
            className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </div>

        {error && <p className="text-xs text-red-600">{error}</p>}

        <button type="submit" className="w-full rounded-md bg-ink py-2 text-sm font-medium text-white">
          Create page
        </button>
      </form>
    </div>
  );
}
