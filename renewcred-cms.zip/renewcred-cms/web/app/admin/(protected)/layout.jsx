'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSelector, useDispatch } from 'react-redux';
import Link from 'next/link';
import { logout, hydrateFromStorage } from '../../../store/slices/authSlice';

// Client-side route guard. Good enough for this assignment's scope; a
// production build would also verify the JWT server-side (middleware.js)
// so protected pages never even flash before redirecting.
export default function ProtectedAdminLayout({ children }) {
  const dispatch = useDispatch();
  const router = useRouter();
  const { isAuthenticated } = useSelector((state) => state.auth);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    dispatch(hydrateFromStorage());
    setChecked(true);
  }, [dispatch]);

  useEffect(() => {
    if (checked && !isAuthenticated) {
      router.replace('/admin/login');
    }
  }, [checked, isAuthenticated, router]);

  if (!checked || !isAuthenticated) {
    return <div className="flex min-h-screen items-center justify-center text-sm text-neutral-400">Loading…</div>;
  }

  function handleLogout() {
    dispatch(logout());
    router.push('/admin/login');
  }

  return (
    <div className="flex min-h-screen bg-neutral-50">
      <aside className="w-56 shrink-0 border-r border-neutral-200 bg-white p-4">
        <div className="mb-6 px-2 text-sm font-semibold text-ink">RenewCred Admin</div>
        <nav className="space-y-1 text-sm">
          <Link href="/admin/dashboard" className="block rounded px-2 py-1.5 text-neutral-600 hover:bg-neutral-100">
            Pages
          </Link>
          <Link
            href="/admin/pages/new"
            className="block rounded px-2 py-1.5 text-neutral-600 hover:bg-neutral-100"
          >
            + New page
          </Link>
        </nav>
        <button
          onClick={handleLogout}
          className="mt-8 w-full rounded-md border border-neutral-200 px-2 py-1.5 text-left text-sm text-neutral-500 hover:bg-neutral-100"
        >
          Log out
        </button>
      </aside>
      <main className="flex-1 p-6 sm:p-8">{children}</main>
    </div>
  );
}
