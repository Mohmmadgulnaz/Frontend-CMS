'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAdminPages, deletePage } from '../../../../store/slices/contentSlice';

export default function DashboardPage() {
  const dispatch = useDispatch();
  const { pages, listStatus } = useSelector((state) => state.content);

  useEffect(() => {
    dispatch(fetchAdminPages());
  }, [dispatch]);

  async function handleDelete(slug) {
    if (window.confirm(`Delete page "${slug}"? This cannot be undone.`)) {
      dispatch(deletePage(slug));
    }
  }

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-ink">Pages</h1>
        <Link href="/admin/pages/new" className="rounded-md bg-ink px-3 py-1.5 text-sm text-white">
          + New page
        </Link>
      </div>

      {listStatus === 'loading' && <p className="text-sm text-neutral-400">Loading…</p>}

      <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
        <table className="min-w-full divide-y divide-neutral-200 text-sm">
          <thead className="bg-neutral-50 text-left text-neutral-500">
            <tr>
              <th className="px-4 py-2.5 font-medium">Title</th>
              <th className="px-4 py-2.5 font-medium">Slug</th>
              <th className="px-4 py-2.5 font-medium">Status</th>
              <th className="px-4 py-2.5 font-medium">Updated</th>
              <th className="px-4 py-2.5" />
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {pages.map((page) => (
              <tr key={page.slug}>
                <td className="px-4 py-2.5 font-medium text-ink">{page.title}</td>
                <td className="px-4 py-2.5 text-neutral-500">/{page.slug}</td>
                <td className="px-4 py-2.5">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs ${
                      page.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-neutral-100 text-neutral-500'
                    }`}
                  >
                    {page.status}
                  </span>
                </td>
                <td className="px-4 py-2.5 text-neutral-500">{new Date(page.updated_at).toLocaleDateString()}</td>
                <td className="px-4 py-2.5 text-right">
                  <Link href={`/admin/pages/${page.slug}/edit`} className="mr-3 text-ink underline">
                    Edit
                  </Link>
                  <button onClick={() => handleDelete(page.slug)} className="text-red-600 underline">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {pages.length === 0 && listStatus === 'succeeded' && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-neutral-400">
                  No pages yet. Create your first one.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
