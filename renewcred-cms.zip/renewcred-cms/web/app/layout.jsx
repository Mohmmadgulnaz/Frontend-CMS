import './globals.css';
import StoreProvider from '../components/StoreProvider';

export const metadata = {
  title: 'RenewCred',
  description: 'RenewCred Standards - carbon credit methodology documentation'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-paper text-ink font-sans antialiased">
        <StoreProvider>{children}</StoreProvider>
      </body>
    </html>
  );
}
