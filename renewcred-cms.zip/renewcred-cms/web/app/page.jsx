import { notFound } from 'next/navigation';
import SiteHeader from '../components/SiteHeader';
import SiteFooter from '../components/SiteFooter';
import BlockRenderer from '../components/BlockRenderer';
import { getPublicPage } from '../lib/content';

// Content is managed live via the CMS, so render on every request rather
// than baking a snapshot in at build time.
export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const page = await getPublicPage('renewcred-standards');
  if (!page) notFound();

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-5xl px-6 py-10">
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-accent">Documentation</p>
        <h1 className="mb-2 text-3xl font-bold tracking-tight text-ink">{page.title}</h1>
        {page.description && <p className="mb-8 max-w-xl text-neutral-500">{page.description}</p>}
        <BlockRenderer blocks={page.blocks} />
      </main>
      <SiteFooter />
    </>
  );
}
