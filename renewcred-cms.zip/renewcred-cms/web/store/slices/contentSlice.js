import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../lib/api';

// Redux owns admin content state because the page list (sidebar), the
// currently-open editor, and save status all need to stay in sync across
// sibling components. Per-field form inputs inside the block editor stay
// as local component state (see BlockEditor) - that churn doesn't need
// to be global.

export const fetchAdminPages = createAsyncThunk('content/fetchAdminPages', async (_, { rejectWithValue }) => {
  try {
    const res = await api.get('/content/admin/pages');
    return res.data.pages;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Failed to load pages.');
  }
});

export const fetchAdminPage = createAsyncThunk('content/fetchAdminPage', async (slug, { rejectWithValue }) => {
  try {
    const res = await api.get(`/content/admin/pages/${slug}`);
    return res.data.page;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Failed to load page.');
  }
});

export const createPage = createAsyncThunk('content/createPage', async (payload, { rejectWithValue }) => {
  try {
    const res = await api.post('/content/admin/pages', payload);
    return res.data.page;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Failed to create page.');
  }
});

export const updatePageMeta = createAsyncThunk('content/updatePageMeta', async ({ slug, meta }, { rejectWithValue }) => {
  try {
    const res = await api.put(`/content/admin/pages/${slug}`, meta);
    return res.data.page;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Failed to update page.');
  }
});

export const saveBlocks = createAsyncThunk('content/saveBlocks', async ({ slug, blocks }, { rejectWithValue }) => {
  try {
    const res = await api.put(`/content/admin/pages/${slug}/blocks`, { blocks });
    return res.data.page;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Failed to save content.');
  }
});

export const deletePage = createAsyncThunk('content/deletePage', async (slug, { rejectWithValue }) => {
  try {
    await api.delete(`/content/admin/pages/${slug}`);
    return slug;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Failed to delete page.');
  }
});

const contentSlice = createSlice({
  name: 'content',
  initialState: {
    pages: [],
    currentPage: null,
    listStatus: 'idle',
    editorStatus: 'idle',
    saveStatus: 'idle',
    error: null
  },
  reducers: {
    clearCurrentPage: (state) => {
      state.currentPage = null;
      state.editorStatus = 'idle';
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAdminPages.pending, (state) => {
        state.listStatus = 'loading';
      })
      .addCase(fetchAdminPages.fulfilled, (state, action) => {
        state.listStatus = 'succeeded';
        state.pages = action.payload;
      })
      .addCase(fetchAdminPages.rejected, (state, action) => {
        state.listStatus = 'failed';
        state.error = action.payload;
      })
      .addCase(fetchAdminPage.pending, (state) => {
        state.editorStatus = 'loading';
      })
      .addCase(fetchAdminPage.fulfilled, (state, action) => {
        state.editorStatus = 'succeeded';
        state.currentPage = action.payload;
      })
      .addCase(fetchAdminPage.rejected, (state, action) => {
        state.editorStatus = 'failed';
        state.error = action.payload;
      })
      .addCase(createPage.fulfilled, (state, action) => {
        state.pages.unshift(action.payload);
      })
      .addCase(updatePageMeta.fulfilled, (state, action) => {
        state.currentPage = action.payload;
        const idx = state.pages.findIndex((p) => p.slug === action.payload.slug);
        if (idx >= 0) state.pages[idx] = { ...state.pages[idx], ...action.payload };
      })
      .addCase(saveBlocks.pending, (state) => {
        state.saveStatus = 'saving';
      })
      .addCase(saveBlocks.fulfilled, (state, action) => {
        state.saveStatus = 'succeeded';
        state.currentPage = action.payload;
      })
      .addCase(saveBlocks.rejected, (state, action) => {
        state.saveStatus = 'failed';
        state.error = action.payload;
      })
      .addCase(deletePage.fulfilled, (state, action) => {
        state.pages = state.pages.filter((p) => p.slug !== action.payload);
      });
  }
});

export const { clearCurrentPage } = contentSlice.actions;
export default contentSlice.reducer;
