import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../lib/api';

// Auth belongs in Redux (not local component state) because the token
// and admin identity are needed across unrelated parts of the tree:
// the sidebar, the route guard, and every page/blocks API call.
export const loginAdmin = createAsyncThunk('auth/loginAdmin', async (credentials, { rejectWithValue }) => {
  try {
    const response = await api.post('/auth/login', credentials);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('adminToken', response.data.token);
    }
    return response.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Login failed.');
  }
});

const initialToken = typeof window !== 'undefined' ? window.localStorage.getItem('adminToken') : null;

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    token: initialToken || null,
    admin: null,
    isAuthenticated: !!initialToken,
    isLoading: false,
    error: null
  },
  reducers: {
    logout: (state) => {
      if (typeof window !== 'undefined') window.localStorage.removeItem('adminToken');
      state.token = null;
      state.admin = null;
      state.isAuthenticated = false;
    },
    hydrateFromStorage: (state) => {
      if (typeof window !== 'undefined') {
        const token = window.localStorage.getItem('adminToken');
        state.token = token || null;
        state.isAuthenticated = !!token;
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginAdmin.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(loginAdmin.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isAuthenticated = true;
        state.token = action.payload.token;
        state.admin = action.payload.admin;
      })
      .addCase(loginAdmin.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  }
});

export const { logout, hydrateFromStorage } = authSlice.actions;
export default authSlice.reducer;
