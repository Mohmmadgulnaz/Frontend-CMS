import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import contentReducer from './slices/contentSlice';

export function makeStore() {
  return configureStore({
    reducer: {
      auth: authReducer,
      content: contentReducer
    }
  });
}

const store = makeStore();
export default store;
