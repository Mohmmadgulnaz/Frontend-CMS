import Link from 'next/link';

export default function SiteHeader() {
  return (
    <header className="border-b border-neutral-200 bg-white">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
        <Link href="/" className="text-sm font-semibold tracking-tight text-ink">
          RenewCred
        </Link>
        <nav className="flex items-center gap-6 text-sm text-neutral-500">
          <span>Reports</span>
          <span>Standards</span>
          <span>Registry</span>
          <span>Marketplace</span>
          <span>Contact</span>
          <button className="rounded-full bg-ink px-4 py-1.5 text-xs font-medium text-white">Sign In</button>
        </nav>
      </div>
    </header>
  );
}
