'use client';

import 'katex/dist/katex.min.css';
import { InlineMath, BlockMath } from 'react-katex';
import { Zap, Flame, Droplet, Sun, ArrowRight } from 'lucide-react';
import Link from 'next/link';

// Maps the small set of icon names stored in card_grid block data to
// actual lucide components. Kept as a lookup table (not a switch) so
// adding a new icon is a one-line change.
const ICONS = { zap: Zap, flame: Flame, droplet: Droplet, sun: Sun };

export default function BlockRenderer({ blocks = [] }) {
  const sorted = [...blocks].sort((a, b) => a.order - b.order);

  return (
    <div className="space-y-8">
      {sorted.map((block) => {
        switch (block.type) {
          case 'header':
            return (
              <h2
                key={block.id}
                id={block.data.anchor}
                className="scroll-mt-24 text-xl font-semibold tracking-tight text-ink"
              >
                {block.data.text}
              </h2>
            );

          case 'paragraph':
            return (
              <p key={block.id} className="text-[15px] leading-7 text-neutral-600">
                {block.data.text}
              </p>
            );

          case 'list':
            return (
              <ul
                key={block.id}
                className={`space-y-2 pl-5 text-[15px] leading-7 text-neutral-600 ${
                  block.data.style === 'ordered' ? 'list-decimal' : 'list-disc'
                }`}
              >
                {block.data.items.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            );

          case 'equation':
            return (
              <div key={block.id} className="my-2 overflow-x-auto rounded-lg border border-neutral-200 bg-white p-4">
                {block.data.displayMode ? (
                  <BlockMath math={block.data.equation} />
                ) : (
                  <InlineMath math={block.data.equation} />
                )}
              </div>
            );

          case 'table':
            return (
              <div key={block.id} className="my-2 overflow-x-auto rounded-lg border border-neutral-200">
                <table className="min-w-full divide-y divide-neutral-200 text-sm">
                  <thead className="bg-neutral-50">
                    <tr>
                      {block.data.headers.map((h, i) => (
                        <th key={i} className="px-4 py-2.5 text-left font-medium text-neutral-500">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 bg-white">
                    {block.data.rows.map((row, ri) => (
                      <tr key={ri}>
                        {row.map((cell, ci) => (
                          <td key={ci} className="px-4 py-2.5 text-neutral-700">
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );

          case 'card_grid':
            return (
              <div key={block.id} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {block.data.cards.map((card) => {
                  const Icon = ICONS[card.icon] || Zap;
                  return (
                    <Link
                      key={card.slug}
                      href={`/${card.slug}`}
                      className="group rounded-xl border border-neutral-200 bg-white p-5 transition hover:border-ink hover:shadow-sm"
                    >
                      <Icon className="mb-3 h-5 w-5 text-accent" strokeWidth={1.75} />
                      <h3 className="mb-1.5 font-semibold text-ink">{card.title}</h3>
                      <p className="mb-3 text-sm leading-6 text-neutral-500">{card.body}</p>
                      <span className="inline-flex items-center gap-1 text-sm font-medium text-ink">
                        Read more
                        <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
                      </span>
                    </Link>
                  );
                })}
              </div>
            );

          default:
            return (
              <div key={block.id} className="rounded border border-yellow-300 bg-yellow-50 p-3 text-xs text-yellow-800">
                Unknown block type: {block.type}
              </div>
            );
        }
      })}
    </div>
  );
}
