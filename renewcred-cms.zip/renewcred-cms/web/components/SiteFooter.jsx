export default function SiteFooter() {
  return (
    <footer className="mt-16 bg-ink py-10 text-neutral-300">
      <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 sm:flex-row sm:justify-between">
        <div>
          <div className="mb-2 text-sm font-semibold text-white">RenewCred</div>
          <p className="max-w-xs text-xs leading-6 text-neutral-400">
            An open, science-backed framework for verified carbon credit issuance.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-8 text-xs sm:grid-cols-3">
          <div className="space-y-2">
            <div className="font-medium text-white">Product</div>
            <div className="text-neutral-400">Standards</div>
            <div className="text-neutral-400">Registry</div>
          </div>
          <div className="space-y-2">
            <div className="font-medium text-white">Company</div>
            <div className="text-neutral-400">About</div>
            <div className="text-neutral-400">Contact</div>
          </div>
          <div className="col-span-2 space-y-2 sm:col-span-1">
            <div className="font-medium text-white">Stay updated</div>
            <p className="text-neutral-400">No spam, just pure climate intelligence.</p>
          </div>
        </div>
      </div>
      <div className="mx-auto mt-8 max-w-5xl border-t border-white/10 px-6 pt-4 text-xs text-neutral-500">
        © {new Date().getFullYear()} RenewCred. All rights reserved.
      </div>
    </footer>
  );
}
