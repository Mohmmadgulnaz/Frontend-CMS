'use client';

import { InlineMath, BlockMath } from 'react-katex';
import 'katex/dist/katex.min.css';

// Generates a short random id for client-side block tracking before save
// (server re-assigns real ids on the next fetch).
function tempId() {
  return `tmp_${Math.random().toString(36).slice(2, 9)}`;
}

export const BLOCK_TYPES = [
  { type: 'header', label: 'Heading' },
  { type: 'paragraph', label: 'Paragraph' },
  { type: 'list', label: 'List' },
  { type: 'table', label: 'Table' },
  { type: 'equation', label: 'Equation' }
];

export function emptyBlockFor(type) {
  const base = { id: tempId(), order: 0 };
  switch (type) {
    case 'header':
      return { ...base, type, data: { text: '', anchor: '' } };
    case 'paragraph':
      return { ...base, type, data: { text: '' } };
    case 'list':
      return { ...base, type, data: { style: 'unordered', items: [''] } };
    case 'table':
      return { ...base, type, data: { headers: ['Column 1', 'Column 2'], rows: [['', '']] } };
    case 'equation':
      return { ...base, type, data: { equation: '', displayMode: true } };
    default:
      return { ...base, type: 'paragraph', data: { text: '' } };
  }
}

function slugifyAnchor(text) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-');
}

export default function BlockEditor({ blocks, onChange }) {
  function updateBlock(id, updater) {
    onChange(blocks.map((b) => (b.id === id ? updater(b) : b)));
  }

  function removeBlock(id) {
    onChange(blocks.filter((b) => b.id !== id));
  }

  function moveBlock(id, direction) {
    const idx = blocks.findIndex((b) => b.id === id);
    const swapWith = idx + direction;
    if (swapWith < 0 || swapWith >= blocks.length) return;
    const next = [...blocks];
    [next[idx], next[swapWith]] = [next[swapWith], next[idx]];
    onChange(next);
  }

  function addBlock(type) {
    onChange([...blocks, emptyBlockFor(type)]);
  }

  return (
    <div className="space-y-4">
      {blocks.map((block, i) => (
        <div key={block.id} className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="rounded bg-neutral-100 px-2 py-0.5 text-xs font-medium uppercase tracking-wide text-neutral-500">
              {block.type}
            </span>
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <button type="button" onClick={() => moveBlock(block.id, -1)} disabled={i === 0} className="disabled:opacity-30">
                ↑
              </button>
              <button
                type="button"
                onClick={() => moveBlock(block.id, 1)}
                disabled={i === blocks.length - 1}
                className="disabled:opacity-30"
              >
                ↓
              </button>
              <button type="button" onClick={() => removeBlock(block.id)} className="text-red-500">
                Remove
              </button>
            </div>
          </div>

          {block.type === 'header' && (
            <input
              value={block.data.text}
              onChange={(e) =>
                updateBlock(block.id, (b) => ({
                  ...b,
                  data: { text: e.target.value, anchor: slugifyAnchor(e.target.value) }
                }))
              }
              placeholder="Heading text"
              className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm font-medium"
            />
          )}

          {block.type === 'paragraph' && (
            <textarea
              value={block.data.text}
              onChange={(e) => updateBlock(block.id, (b) => ({ ...b, data: { text: e.target.value } }))}
              rows={3}
              placeholder="Paragraph text"
              className="w-full rounded-md border border-neutral-300 px-3 py-2 text-sm"
            />
          )}

          {block.type === 'list' && (
            <div className="space-y-2">
              <select
                value={block.data.style}
                onChange={(e) =>
                  updateBlock(block.id, (b) => ({ ...b, data: { ...b.data, style: e.target.value } }))
                }
                className="rounded-md border border-neutral-300 px-2 py-1 text-xs"
              >
                <option value="unordered">Bulleted</option>
                <option value="ordered">Numbered</option>
              </select>
              {block.data.items.map((item, idx) => (
                <div key={idx} className="flex gap-2">
                  <input
                    value={item}
                    onChange={(e) =>
                      updateBlock(block.id, (b) => {
                        const items = [...b.data.items];
                        items[idx] = e.target.value;
                        return { ...b, data: { ...b.data, items } };
                      })
                    }
                    className="flex-1 rounded-md border border-neutral-300 px-3 py-1.5 text-sm"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      updateBlock(block.id, (b) => ({
                        ...b,
                        data: { ...b.data, items: b.data.items.filter((_, i2) => i2 !== idx) }
                      }))
                    }
                    className="text-xs text-red-500"
                  >
                    ✕
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  updateBlock(block.id, (b) => ({ ...b, data: { ...b.data, items: [...b.data.items, ''] } }))
                }
                className="text-xs text-ink underline"
              >
                + Add item
              </button>
            </div>
          )}

          {block.type === 'table' && (
            <div className="space-y-2 overflow-x-auto">
              <div className="flex gap-2">
                {block.data.headers.map((h, idx) => (
                  <input
                    key={idx}
                    value={h}
                    onChange={(e) =>
                      updateBlock(block.id, (b) => {
                        const headers = [...b.data.headers];
                        headers[idx] = e.target.value;
                        return { ...b, data: { ...b.data, headers } };
                      })
                    }
                    className="w-32 rounded-md border border-neutral-300 px-2 py-1 text-xs font-medium"
                  />
                ))}
                <button
                  type="button"
                  onClick={() =>
                    updateBlock(block.id, (b) => ({
                      ...b,
                      data: {
                        headers: [...b.data.headers, `Column ${b.data.headers.length + 1}`],
                        rows: b.data.rows.map((r) => [...r, ''])
                      }
                    }))
                  }
                  className="text-xs text-ink underline"
                >
                  + Column
                </button>
              </div>
              {block.data.rows.map((row, rIdx) => (
                <div key={rIdx} className="flex gap-2">
                  {row.map((cell, cIdx) => (
                    <input
                      key={cIdx}
                      value={cell}
                      onChange={(e) =>
                        updateBlock(block.id, (b) => {
                          const rows = b.data.rows.map((r) => [...r]);
                          rows[rIdx][cIdx] = e.target.value;
                          return { ...b, data: { ...b.data, rows } };
                        })
                      }
                      className="w-32 rounded-md border border-neutral-300 px-2 py-1 text-xs"
                    />
                  ))}
                  <button
                    type="button"
                    onClick={() =>
                      updateBlock(block.id, (b) => ({
                        ...b,
                        data: { ...b.data, rows: b.data.rows.filter((_, i2) => i2 !== rIdx) }
                      }))
                    }
                    className="text-xs text-red-500"
                  >
                    ✕
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  updateBlock(block.id, (b) => ({
                    ...b,
                    data: { ...b.data, rows: [...b.data.rows, b.data.headers.map(() => '')] }
                  }))
                }
                className="text-xs text-ink underline"
              >
                + Row
              </button>
            </div>
          )}

          {block.type === 'equation' && (
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-xs text-neutral-500">
                <input
                  type="checkbox"
                  checked={block.data.displayMode}
                  onChange={(e) =>
                    updateBlock(block.id, (b) => ({ ...b, data: { ...b.data, displayMode: e.target.checked } }))
                  }
                />
                Display as block equation
              </label>
              <input
                value={block.data.equation}
                onChange={(e) => updateBlock(block.id, (b) => ({ ...b, data: { ...b.data, equation: e.target.value } }))}
                placeholder="LaTeX, e.g. E = mc^2"
                className="w-full rounded-md border border-neutral-300 px-3 py-2 font-mono text-sm"
              />
              {block.data.equation && (
                <div className="rounded-md border border-neutral-100 bg-neutral-50 p-3">
                  {block.data.displayMode ? (
                    <BlockMath math={block.data.equation} />
                  ) : (
                    <InlineMath math={block.data.equation} />
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      ))}

      <div className="flex flex-wrap gap-2 rounded-lg border border-dashed border-neutral-300 p-4">
        <span className="mr-2 self-center text-xs text-neutral-400">Add block:</span>
        {BLOCK_TYPES.map((bt) => (
          <button
            key={bt.type}
            type="button"
            onClick={() => addBlock(bt.type)}
            className="rounded-md border border-neutral-300 px-2.5 py-1 text-xs text-neutral-600 hover:bg-neutral-100"
          >
            + {bt.label}
          </button>
        ))}
      </div>
    </div>
  );
}
