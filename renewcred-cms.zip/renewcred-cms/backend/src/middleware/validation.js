const { z } = require('zod');

// Each block "type" gets its own data shape, mirroring the block-based
// schema strategy in the reference doc (Mixed data field, validated at
// the application layer rather than the DB layer).
const blockDataSchemas = {
  header: z.object({ text: z.string().min(1), anchor: z.string().optional() }),
  paragraph: z.object({ text: z.string().min(1) }),
  list: z.object({
    style: z.enum(['ordered', 'unordered']).default('unordered'),
    items: z.array(z.string().min(1)).min(1)
  }),
  table: z.object({
    headers: z.array(z.string()).min(1),
    rows: z.array(z.array(z.string()))
  }),
  equation: z.object({
    equation: z.string().min(1),
    displayMode: z.boolean().default(true)
  }),
  card_grid: z.object({
    cards: z.array(
      z.object({
        icon: z.string().optional(),
        title: z.string().min(1),
        slug: z.string().min(1),
        body: z.string().min(1)
      })
    )
  })
};

const blockSchema = z
  .object({
    type: z.enum(['header', 'paragraph', 'list', 'table', 'equation', 'card_grid']),
    data: z.any()
  })
  .superRefine((block, ctx) => {
    const schema = blockDataSchemas[block.type];
    const result = schema.safeParse(block.data);
    if (!result.success) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `Invalid data for block type "${block.type}": ${result.error.message}`
      });
    }
  });

const pageMetaSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional().default(''),
  status: z.enum(['draft', 'published']).default('draft')
});

const pageCreateSchema = pageMetaSchema.extend({
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9-]+$/, 'Slug must be lowercase, alphanumeric, hyphen-separated')
});

const blocksArraySchema = z.array(blockSchema);

module.exports = { pageCreateSchema, pageMetaSchema, blocksArraySchema, blockSchema };
