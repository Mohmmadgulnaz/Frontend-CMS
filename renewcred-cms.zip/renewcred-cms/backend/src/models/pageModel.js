const db = require('../config/db');

// Thin data-access layer. Keeping raw-ish SQL here (rather than an ORM)
// keeps the block JSON shape flexible per-type, matching the "Mixed"
// data field approach described in the reference doc's Mongoose schema.

function serializeBlock(row) {
  return {
    id: row.id,
    type: row.type,
    order: row.order,
    data: JSON.parse(row.data)
  };
}

function getPageBySlug(slug) {
  const page = db.prepare('SELECT * FROM pages WHERE slug = ?').get(slug);
  if (!page) return null;
  const blocks = db
    .prepare('SELECT * FROM blocks WHERE page_id = ? ORDER BY "order" ASC')
    .all(page.id)
    .map(serializeBlock);
  return { ...page, blocks };
}

function listPages() {
  const pages = db.prepare('SELECT id, slug, title, description, status, updated_at FROM pages ORDER BY updated_at DESC').all();
  return pages;
}

function createPage({ slug, title, description, status }) {
  const stmt = db.prepare(
    'INSERT INTO pages (slug, title, description, status) VALUES (?, ?, ?, ?)'
  );
  const info = stmt.run(slug, title, description || '', status || 'draft');
  return getPageBySlug(slug) || { id: info.lastInsertRowid, slug, title };
}

function updatePageMeta(id, { title, description, status }) {
  db.prepare(
    `UPDATE pages SET title = ?, description = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(title, description, status, id);
}

function deletePage(id) {
  db.prepare('DELETE FROM pages WHERE id = ?').run(id);
}

// Replaces the full block set for a page in one transaction.
// Simpler and safer for this assignment's scope than diffing individual
// block CRUD operations; the editor always sends the full ordered array.
const replaceBlocksTx = db.transaction((pageId, blocks) => {
  db.prepare('DELETE FROM blocks WHERE page_id = ?').run(pageId);
  const insert = db.prepare(
    'INSERT INTO blocks (page_id, type, data, "order") VALUES (?, ?, ?, ?)'
  );
  blocks.forEach((block, index) => {
    insert.run(pageId, block.type, JSON.stringify(block.data), index);
  });
});

function replaceBlocks(pageId, blocks) {
  replaceBlocksTx(pageId, blocks);
}

module.exports = {
  getPageBySlug,
  listPages,
  createPage,
  updatePageMeta,
  deletePage,
  replaceBlocks
};
