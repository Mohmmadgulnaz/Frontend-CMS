const db = require('../config/db');

function findByUsername(username) {
  return db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
}

function createAdmin({ username, email, passwordHash }) {
  const info = db
    .prepare('INSERT INTO admins (username, email, password_hash) VALUES (?, ?, ?)')
    .run(username, email, passwordHash);
  return { id: info.lastInsertRowid, username, email };
}

function countAdmins() {
  return db.prepare('SELECT COUNT(*) as count FROM admins').get().count;
}

module.exports = { findByUsername, createAdmin, countAdmins };
