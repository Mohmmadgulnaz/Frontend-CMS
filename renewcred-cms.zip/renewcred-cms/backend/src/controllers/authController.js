const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const adminModel = require('../models/adminModel');

async function login(req, res) {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password are required.' });
  }

  const admin = adminModel.findByUsername(username);
  if (!admin) {
    return res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }

  const isMatch = await bcrypt.compare(password, admin.password_hash);
  if (!isMatch) {
    return res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }

  const token = jwt.sign(
    { id: admin.id, username: admin.username },
    process.env.JWT_SECRET || 'dev_fallback_secret',
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );

  return res.json({
    success: true,
    token,
    admin: { id: admin.id, username: admin.username, email: admin.email }
  });
}

// Logout is stateless (JWT) - the client discards the token. This endpoint
// exists mainly for API symmetry / future denylist support.
function logout(req, res) {
  res.json({ success: true, message: 'Logged out.' });
}

function me(req, res) {
  res.json({ success: true, admin: req.admin });
}

module.exports = { login, logout, me };
