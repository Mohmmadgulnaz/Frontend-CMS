const pageModel = require('../models/pageModel');
const { pageCreateSchema, pageMetaSchema, blocksArraySchema } = require('../middleware/validation');

// Public: list only published pages (used by e.g. nav/sitemaps)
function listPublicPages(req, res) {
  const pages = pageModel.listPages().filter((p) => p.status === 'published');
  res.json({ success: true, pages });
}

// Public: fetch a single published page by slug, with its ordered blocks
function getPublicPage(req, res) {
  const page = pageModel.getPageBySlug(req.params.slug);
  if (!page || page.status !== 'published') {
    return res.status(404).json({ success: false, message: 'Page not found.' });
  }
  res.json({ success: true, page });
}

// Admin: list all pages regardless of status
function listAdminPages(req, res) {
  res.json({ success: true, pages: pageModel.listPages() });
}

function getAdminPage(req, res) {
  const page = pageModel.getPageBySlug(req.params.slug);
  if (!page) return res.status(404).json({ success: false, message: 'Page not found.' });
  res.json({ success: true, page });
}

function createPage(req, res) {
  const parsed = pageCreateSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ success: false, message: parsed.error.errors[0].message });
  }
  if (pageModel.getPageBySlug(parsed.data.slug)) {
    return res.status(409).json({ success: false, message: 'A page with this slug already exists.' });
  }
  const page = pageModel.createPage(parsed.data);
  res.status(201).json({ success: true, page });
}

function updatePageMeta(req, res) {
  const page = pageModel.getPageBySlug(req.params.slug);
  if (!page) return res.status(404).json({ success: false, message: 'Page not found.' });

  const parsed = pageMetaSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ success: false, message: parsed.error.errors[0].message });
  }
  pageModel.updatePageMeta(page.id, parsed.data);
  res.json({ success: true, page: pageModel.getPageBySlug(req.params.slug) });
}

function updatePageBlocks(req, res) {
  const page = pageModel.getPageBySlug(req.params.slug);
  if (!page) return res.status(404).json({ success: false, message: 'Page not found.' });

  const parsed = blocksArraySchema.safeParse(req.body.blocks);
  if (!parsed.success) {
    return res.status(400).json({ success: false, message: parsed.error.errors[0].message });
  }
  pageModel.replaceBlocks(page.id, parsed.data);
  res.json({ success: true, page: pageModel.getPageBySlug(req.params.slug) });
}

function deletePage(req, res) {
  const page = pageModel.getPageBySlug(req.params.slug);
  if (!page) return res.status(404).json({ success: false, message: 'Page not found.' });
  pageModel.deletePage(page.id);
  res.json({ success: true });
}

module.exports = {
  listPublicPages,
  getPublicPage,
  listAdminPages,
  getAdminPage,
  createPage,
  updatePageMeta,
  updatePageBlocks,
  deletePage
};
