const express = require('express');
const protectRoute = require('../middleware/authMiddleware');
const ctrl = require('../controllers/contentController');

const router = express.Router();

// Public, read-only
router.get('/public/pages', ctrl.listPublicPages);
router.get('/public/pages/:slug', ctrl.getPublicPage);

// Admin, JWT-protected
router.get('/admin/pages', protectRoute, ctrl.listAdminPages);
router.get('/admin/pages/:slug', protectRoute, ctrl.getAdminPage);
router.post('/admin/pages', protectRoute, ctrl.createPage);
router.put('/admin/pages/:slug', protectRoute, ctrl.updatePageMeta);
router.put('/admin/pages/:slug/blocks', protectRoute, ctrl.updatePageBlocks);
router.delete('/admin/pages/:slug', protectRoute, ctrl.deletePage);

module.exports = router;
