require('dotenv').config();
const bcrypt = require('bcryptjs');
const adminModel = require('../models/adminModel');
const pageModel = require('../models/pageModel');

function seedAdmin() {
  const username = process.env.SEED_ADMIN_USERNAME || 'admin';
  const email = process.env.SEED_ADMIN_EMAIL || 'admin@renewcred.dev';
  const password = process.env.SEED_ADMIN_PASSWORD || 'ChangeMe123!';

  if (adminModel.findByUsername(username)) {
    console.log(`Admin "${username}" already exists, skipping.`);
    return;
  }
  const passwordHash = bcrypt.hashSync(password, 10);
  adminModel.createAdmin({ username, email, passwordHash });
  console.log(`Seeded admin user -> username: ${username} / password: ${password}`);
}

function seedStandardsPage() {
  if (pageModel.getPageBySlug('renewcred-standards')) {
    console.log('renewcred-standards page already exists, skipping.');
  } else {
    const page = pageModel.createPage({
      slug: 'renewcred-standards',
      title: 'RenewCred Standards',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      status: 'published'
    });

    pageModel.replaceBlocks(page.id, [
      {
        type: 'card_grid',
        data: {
          cards: [
            {
              icon: 'zap',
              title: 'EV',
              slug: 'ev',
              body:
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio praesent libero.'
            },
            {
              icon: 'flame',
              title: 'Biochar',
              slug: 'biochar',
              body:
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed cursus ante dapibus diam.'
            },
            {
              icon: 'droplet',
              title: 'Methane',
              slug: 'methane',
              body:
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis sem at nibh elementum.'
            },
            {
              icon: 'sun',
              title: 'Renewable Energy',
              slug: 'renewable-energy',
              body:
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ante ipsum primis.'
            }
          ]
        }
      }
    ]);
  }

  if (pageModel.getPageBySlug('ev')) {
    console.log('ev page already exists, skipping.');
    return;
  }

  const evPage = pageModel.createPage({
    slug: 'ev',
    title: 'EV',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie.',
    status: 'published'
  });

  pageModel.replaceBlocks(evPage.id, [
    { type: 'header', data: { text: '1.0 Introduction', anchor: '1-0-introduction' } },
    {
      type: 'paragraph',
      data: {
        text:
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.'
      }
    },
    {
      type: 'list',
      data: {
        style: 'unordered',
        items: [
          'Duis sagittis ipsum, praesent mauris fusce nec tellus sed.',
          'Augue semper porta mauris massa vestibulum lacinia arcu eget.',
          'Nulla facilisi morbi tempus iaculis urna id volutpat lacus.'
        ]
      }
    },
    { type: 'header', data: { text: '2.0 Future Versions', anchor: '2-0-future-versions' } },
    {
      type: 'paragraph',
      data: {
        text:
          'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Donec pede justo, fringilla vel, aliquet nec.'
      }
    },
    {
      type: 'equation',
      data: {
        displayMode: true,
        equation: 'E_{credit} = \\sum_{i=1}^{n} (kWh_i \\times EF_i) \\times AF'
      }
    },
    {
      type: 'table',
      data: {
        headers: ['Version', 'Emission Factor', 'Adjustment Factor'],
        rows: [
          ['2.0', '0.82', '1.00'],
          ['2.1', '0.79', '1.02'],
          ['3.1', '0.71', '1.05']
        ]
      }
    },
    { type: 'header', data: { text: '3.1 Future Versions', anchor: '3-1-future-versions' } },
    {
      type: 'paragraph',
      data: {
        text:
          'Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum.'
      }
    },
    { type: 'header', data: { text: '3.2 Future Versions', anchor: '3-2-future-versions' } },
    {
      type: 'paragraph',
      data: {
        text:
          'Praesent mauris. Fusce nec tellus sed augue semper porta. Mauris massa vestibulum lacinia arcu eget nulla.'
      }
    }
  ]);

  console.log('Seeded "renewcred-standards" and "ev" pages.');
}

seedAdmin();
seedStandardsPage();
console.log('Seed complete.');
