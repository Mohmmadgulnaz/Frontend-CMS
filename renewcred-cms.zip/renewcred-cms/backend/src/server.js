require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const contentRoutes = require('./routes/content');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || '*' }));
app.use(express.json({ limit: '2mb' }));

app.get('/api/v1/health', (req, res) => res.json({ success: true, status: 'ok' }));

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/content', contentRoutes);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`RenewCred backend listening on http://localhost:${PORT}`);
});
